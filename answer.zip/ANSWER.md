# Java编程基础 - 集合运算

### 如何下载
+ 答案详情请点击上方 作业答案下载，来下载 `answer.zip` 压缩包文件 

### 如何启动
+ 解压 `answer.zip`，用 IntelliJ IDE 打开
+ 运行测试
    根目录下执行`./gradlew clean test`
    
### 重点讲解
+ 仔细阅读 `test` 文件夹里的每个题目，确定题目的需求
+ 学习java集合的一些方法，完成实现    
    